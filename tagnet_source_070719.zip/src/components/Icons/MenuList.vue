<template>
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="4" viewBox="0 0 16 4">
  <g class="goal-fill" data-name="Group 228" transform="translate(-326 -401)">
    <circle class="goal-fill" data-name="Ellipse 126" cx="2" cy="2" r="2" transform="translate(342 405) rotate(180)" fill="#96a5ff"/>
    <circle class="goal-fill" data-name="Ellipse 127" cx="2" cy="2" r="2" transform="translate(336 405) rotate(180)" fill="#96a5ff"/>
    <circle class="goal-fill" data-name="Ellipse 128" cx="2" cy="2" r="2" transform="translate(330 405) rotate(180)" fill="#96a5ff"/>
  </g>
</svg>

</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class MenuList extends Vue {}
</script>

<style scoped lang="scss">
</style>
