<template>
<svg xmlns="http://www.w3.org/2000/svg" width="13.719" height="8" viewBox="0 0 13.719 8">
  <path id="Path_124" data-name="Path 124" d="M1.457,82.356a.432.432,0,0,0-.632,0l-.687.687a.433.433,0,0,0,0,.632l5.4,5.4-5.4,5.4a.433.433,0,0,0,0,.632l.687.687a.432.432,0,0,0,.632,0l6.406-6.406a.433.433,0,0,0,0-.632Z" transform="translate(95.938) rotate(90)" opacity="0.32"/>
</svg>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class ArrowDown extends Vue {}
</script>

<style scoped lang="scss">
</style>
