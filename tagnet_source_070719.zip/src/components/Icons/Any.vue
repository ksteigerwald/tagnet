<template>
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
  <path class="goal-fill"  d="M14.333,0H1.667A1.669,1.669,0,0,0,0,1.667V14.333A1.669,1.669,0,0,0,1.667,16H14.333A1.669,1.669,0,0,0,16,14.333V1.667A1.669,1.669,0,0,0,14.333,0Zm.333,1.667V7.333h-6v-6h5.667a.334.334,0,0,1,.333.333Zm-13-.333H7.333v6h-6V1.667a.334.334,0,0,1,.333-.333Zm-.333,13V8.667h6v6H1.667a.334.334,0,0,1-.333-.333Zm13,.333H8.667v-6h6v5.667a.334.334,0,0,1-.333.333Zm0,0" fill="#b1e7d9"/>
</svg>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class Any extends Vue {}
</script>

<style scoped lang="scss">
</style>
