<template>
<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
  <g id="Group_197" data-name="Group 197" transform="translate(-634 -516)">
    <circle id="Ellipse_105" data-name="Ellipse 105" cx="16" cy="16" r="16" transform="translate(634 516)" fill="#f1ceda" opacity="0.3"/>
    <g id="solution" transform="translate(546.052 524)">
      <g id="Group_190" data-name="Group 190" transform="translate(98.948 2.754)">
        <g id="Group_189" data-name="Group 189" transform="translate(0)">
          <path class="goal-fill" data-name="Path 137" d="M108.764,93.044a4.908,4.908,0,1,0-7.587,4.113V98.7a2.679,2.679,0,0,0,5.358,0V97.157A4.925,4.925,0,0,0,108.764,93.044ZM105.589,98.7a1.733,1.733,0,0,1-3.466,0v-.4h3.466Zm.237-2.221a.473.473,0,0,0-.237.41v.469h-1.26V94.915a1.535,1.535,0,0,0,1.06-1.458.473.473,0,1,0-.946,0,.587.587,0,1,1-1.173,0,.473.473,0,1,0-.946,0,1.535,1.535,0,0,0,1.06,1.458v2.446h-1.26v-.469a.473.473,0,0,0-.237-.41,3.962,3.962,0,1,1,3.94,0Z" transform="translate(-98.948 -88.136)" fill="#f1ceda"/>
        </g>
      </g>
      <g id="Group_192" data-name="Group 192" transform="translate(103.383)">
        <g id="Group_191" data-name="Group 191" transform="translate(0)">
          <path class="goal-fill" data-name="Path 138" d="M241.334,0a.473.473,0,0,0-.473.473V1.3a.473.473,0,0,0,.946,0V.473A.473.473,0,0,0,241.334,0Z" transform="translate(-240.861)" fill="#f1ceda"/>
        </g>
      </g>
      <g id="Group_194" data-name="Group 194" transform="translate(101.316 0.342)">
        <g id="Group_193" data-name="Group 193" transform="translate(0)">
          <path class="goal-fill" data-name="Path 139" d="M175.929,12.029l-.294-.777a.473.473,0,0,0-.885.335l.294.777a.473.473,0,0,0,.885-.335Z" transform="translate(-174.719 -10.947)" fill="#f1ceda"/>
        </g>
      </g>
      <g id="Group_196" data-name="Group 196" transform="translate(105.156 0.342)">
        <g id="Group_195" data-name="Group 195" transform="translate(0)">
          <path class="goal-fill" data-name="Path 140" d="M298.534,10.977a.473.473,0,0,0-.61.275l-.294.777a.473.473,0,1,0,.885.334l.294-.777A.473.473,0,0,0,298.534,10.977Z" transform="translate(-297.6 -10.946)" fill="#f1ceda"/>
        </g>
      </g>
    </g>
  </g>
</svg>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class Idea extends Vue {}
</script>

<style scoped lang="scss">
</style>
