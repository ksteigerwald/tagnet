<template>
<svg xmlns="http://www.w3.org/2000/svg" width="17.4" height="18.667" viewBox="0 0 17.4 18.667">
  <g id="delete" transform="translate(0)">
    <g id="Group_212" data-name="Group 212" transform="translate(0 2.802)">
      <g id="Group_211" data-name="Group 211">
        <g id="Group_210" data-name="Group 210">
          <path class="goal-fill" data-name="Path 143" d="M306.585,175.11l-1.461-.054-.317,8.651,1.461.053Z" transform="translate(-294.328 -171.476)" fill="#ff6956"/>
          <rect class="goal-fill" data-name="Rectangle 205" width="1.462" height="8.651" transform="translate(7.969 3.607)" fill="#ff6956"/>
          <path class="goal-fill" data-name="Path 144" d="M160.2,183.7l-.317-8.651-1.461.054.317,8.651Z" transform="translate(-153.277 -171.469)" fill="#ff6956"/>
          <path class="goal-fill" data-name="Path 145" d="M17.379,76.867v1.462H18.9l1.209,13.735a.731.731,0,0,0,.728.667H31.293a.731.731,0,0,0,.728-.667L33.23,78.329h1.548V76.867Zm13.245,14.4H21.509L20.37,78.329H31.763Z" transform="translate(-17.379 -76.867)" fill="#ff6956"/>
        </g>
      </g>
    </g>
    <g id="Group_214" data-name="Group 214" transform="translate(5.093)">
      <g id="Group_213" data-name="Group 213">
        <path class="goal-fill" data-name="Path 146" d="M163.071,0h-4.776a1.22,1.22,0,0,0-1.218,1.218V3.534h1.462V1.462h4.289V3.534h1.462V1.218A1.22,1.22,0,0,0,163.071,0Z" transform="translate(-157.076)" fill="#ff6956"/>
      </g>
    </g>
  </g>
</svg>

</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class TrashCan extends Vue {}
</script>

<style scoped lang="scss">
</style>
