<template>
<div>
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="15.997" viewBox="0 0 16 15.997">
   <g id="Group_35" data-name="Group 35" transform="translate(0)">
      <path class="goal-fill" data-name="Path 26" d="M183.18,7.13A1.524,1.524,0,1,0,184.3,8.6a1.5,1.5,0,0,0-.056-.406l4.245-4.245.687.092,2.149-2.149L189.7,1.675,189.481.05,187.333,2.2l.092.687Z" transform="translate(-175.323 -0.05)" fill="#96a5ff"/>
      <path class="goal-fill" data-name="Path 27" d="M97.4,127.876l1.256-1.256a4.416,4.416,0,1,0,2.763,2.76l-1.256,1.256a2.932,2.932,0,1,1-2.763-2.76Z" transform="translate(-89.789 -122.254)" fill="#96a5ff"/>
      <path class="goal-fill" data-name="Path 28" d="M12.717,38.624a5.827,5.827,0,1,1-2.763-2.763l1.2-1.2a7.448,7.448,0,1,0,2.76,2.76Z" transform="translate(0 -32.578)" fill="#96a5ff"/>
   </g>
  </svg> 
</div> 
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class Goal extends Vue {}
</script>

<style scoped lang="scss">
</style>
