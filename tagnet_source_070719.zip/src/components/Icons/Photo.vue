<template>
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="18.93" viewBox="0 0 24 18.93">
  <g id="frame-landscape" transform="translate(0 -33.331)">
    <path class="goal-fill" data-name="Path 171" d="M23.62,33.331H.38a.38.38,0,0,0-.38.38v18.17a.38.38,0,0,0,.38.38H23.62a.38.38,0,0,0,.38-.38V33.711A.38.38,0,0,0,23.62,33.331Zm-1.9,15.9-5.23-5.416a.156.156,0,0,0-.215-.009L12.647,47,8.011,41.289a.153.153,0,0,0-.124-.057.155.155,0,0,0-.121.063L2.282,48.653V35.613H21.718V49.23Z" fill="#dbb7ff"/>
    <path class="goal-fill" data-name="Path 172" d="M187.4,90.222a1.866,1.866,0,1,0-1.865-1.866A1.866,1.866,0,0,0,187.4,90.222Z" transform="translate(-171.421 -49.117)" fill="#dbb7ff"/>
  </g>
</svg>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class Photo extends Vue {}
</script>

<style scoped lang="scss">
</style>
