<template>
<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48">
  <g id="Group_358" data-name="Group 358" transform="translate(-1053 -1039)">
    <circle id="Ellipse_105" data-name="Ellipse 105" cx="24" cy="24" r="24" transform="translate(1053 1039)" fill="#e5e5e5" opacity="0.3"/>
    <path id="Path_15" data-name="Path 15" d="M42.719,76.135a7.545,7.545,0,1,0-2.541-2.541L37.59,76.182h0l-2.57,2.57a14.777,14.777,0,0,0,2.541,2.541l5.158-5.158Zm3.9-10.391a3.944,3.944,0,1,1-3.944,3.944A3.944,3.944,0,0,1,46.624,65.744Z" transform="translate(1031.98 990.85)" fill="#c3c3c3"/>
  </g>
</svg>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class Search extends Vue {}
</script>

<style scoped lang="scss">
</style>
