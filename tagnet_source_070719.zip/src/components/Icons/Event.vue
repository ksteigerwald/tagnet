<template>
<svg id="calendar" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
  <g id="Group_159" data-name="Group 159">
    <g id="Group_158" data-name="Group 158">
      <path class="goal-fill" data-name="Path 136" d="M14.125,1.25h-.75V0h-1.25V1.25H3.875V0H2.625V1.25h-.75A1.877,1.877,0,0,0,0,3.125v11A1.877,1.877,0,0,0,1.875,16h12.25A1.877,1.877,0,0,0,16,14.125v-11A1.877,1.877,0,0,0,14.125,1.25Zm.625,12.875a.626.626,0,0,1-.625.625H1.875a.626.626,0,0,1-.625-.625V5.875h13.5Zm0-9.5H1.25v-1.5A.626.626,0,0,1,1.875,2.5h.75V3.75h1.25V2.5h8.25V3.75h1.25V2.5h.75a.626.626,0,0,1,.625.625Z" fill="#ffde85"/>
    </g>
  </g>
  <g id="Group_161" data-name="Group 161" transform="translate(2.375 7.188)">
    <g id="Group_160" data-name="Group 160">
      <rect class="goal-fill" data-name="Rectangle 176" width="1.25" height="1.25" fill="#ffde85"/>
    </g>
  </g>
  <g id="Group_163" data-name="Group 163" transform="translate(4.875 7.188)">
    <g id="Group_162" data-name="Group 162">
      <rect class="goal-fill" data-name="Rectangle 177" width="1.25" height="1.25" fill="#ffde85"/>
    </g>
  </g>
  <g id="Group_165" data-name="Group 165" transform="translate(7.375 7.188)">
    <g id="Group_164" data-name="Group 164">
      <rect class="goal-fill" data-name="Rectangle 178" width="1.25" height="1.25" fill="#ffde85"/>
    </g>
  </g>
  <g id="Group_167" data-name="Group 167" transform="translate(9.875 7.188)">
    <g id="Group_166" data-name="Group 166">
      <rect class="goal-fill" data-name="Rectangle 179" width="1.25" height="1.25" fill="#ffde85"/>
    </g>
  </g>
  <g id="Group_169" data-name="Group 169" transform="translate(12.375 7.188)">
    <g id="Group_168" data-name="Group 168">
      <rect class="goal-fill" data-name="Rectangle 180" width="1.25" height="1.25" fill="#ffde85"/>
    </g>
  </g>
  <g id="Group_171" data-name="Group 171" transform="translate(2.375 9.688)">
    <g id="Group_170" data-name="Group 170">
      <rect class="goal-fill" data-name="Rectangle 181" width="1.25" height="1.25" fill="#ffde85"/>
    </g>
  </g>
  <g id="Group_173" data-name="Group 173" transform="translate(4.875 9.688)">
    <g id="Group_172" data-name="Group 172">
      <rect class="goal-fill" data-name="Rectangle 182" width="1.25" height="1.25" fill="#ffde85"/>
    </g>
  </g>
  <g id="Group_175" data-name="Group 175" transform="translate(7.375 9.688)">
    <g id="Group_174" data-name="Group 174">
      <rect class="goal-fill" data-name="Rectangle 183" width="1.25" height="1.25" fill="#ffde85"/>
    </g>
  </g>
  <g id="Group_177" data-name="Group 177" transform="translate(9.875 9.688)">
    <g id="Group_176" data-name="Group 176">
      <rect class="goal-fill" data-name="Rectangle 184" width="1.25" height="1.25" fill="#ffde85"/>
    </g>
  </g>
  <g id="Group_179" data-name="Group 179" transform="translate(2.375 12.188)">
    <g id="Group_178" data-name="Group 178">
      <rect class="goal-fill" data-name="Rectangle 185" width="1.25" height="1.25" fill="#ffde85"/>
    </g>
  </g>
  <g id="Group_181" data-name="Group 181" transform="translate(4.875 12.188)">
    <g id="Group_180" data-name="Group 180">
      <rect class="goal-fill" data-name="Rectangle 186" width="1.25" height="1.25" fill="#ffde85"/>
    </g>
  </g>
  <g id="Group_183" data-name="Group 183" transform="translate(7.375 12.188)">
    <g id="Group_182" data-name="Group 182">
      <rect class="goal-fill" data-name="Rectangle 187" width="1.25" height="1.25" fill="#ffde85"/>
    </g>
  </g>
  <g id="Group_185" data-name="Group 185" transform="translate(9.875 12.188)">
    <g id="Group_184" data-name="Group 184">
      <rect class="goal-fill" data-name="Rectangle 188" width="1.25" height="1.25" fill="#ffde85"/>
    </g>
  </g>
  <g id="Group_187" data-name="Group 187" transform="translate(12.375 9.688)">
    <g id="Group_186" data-name="Group 186">
      <rect class="goal-fill" data-name="Rectangle 189" width="1.25" height="1.25" fill="#ffde85"/>
    </g>
  </g>
</svg>

</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class Goal extends Vue {}
</script>

<style scoped lang="scss">
</style>
