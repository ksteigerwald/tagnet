<template>
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <g id="web-link" transform="translate(0 0)">
    <g id="Group_350" data-name="Group 350" transform="translate(0 0)">
      <path id="Path_170" data-name="Path 170" d="M8.789,19.041,7.575,20.247a2.718,2.718,0,0,1-3.817,0,2.641,2.641,0,0,1,0-3.754l4.47-4.435c.926-.919,2.669-2.271,3.939-1.012a1.487,1.487,0,1,0,2.1-2.11C12.1,6.793,8.912,7.189,6.133,9.947l-4.47,4.435a5.613,5.613,0,0,0,0,7.976,5.7,5.7,0,0,0,8.007,0l1.215-1.206a1.487,1.487,0,1,0-2.1-2.11ZM22.336,1.813c-2.319-2.3-5.561-2.426-7.708-.3l-1.514,1.5a1.487,1.487,0,1,0,2.1,2.11l1.513-1.5c1.112-1.1,2.568-.647,3.518.3a2.64,2.64,0,0,1,0,3.755L15.473,12.41c-2.181,2.164-3.2,1.148-3.64.715a1.487,1.487,0,1,0-2.1,2.11,4.69,4.69,0,0,0,3.342,1.486,6.548,6.548,0,0,0,4.489-2.2l4.769-4.731a5.613,5.613,0,0,0,0-7.976Z" transform="translate(0 0)" fill="#dbb7ff"/>
    </g>
  </g>
</svg>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class WebLink extends Vue {}
</script>

<style scoped lang="scss">
</style>
