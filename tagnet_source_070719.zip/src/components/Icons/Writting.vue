<template>
<svg xmlns="http://www.w3.org/2000/svg" width="10.754" height="12" viewBox="0 0 10.754 12">
  <g id="writing" transform="translate(-26.57)">
    <g id="Group_157" data-name="Group 157" transform="translate(26.57)">
      <g id="Group_156" data-name="Group 156">
        <path class="writing-fill" data-name="Path 131" d="M112.225,200.469a.469.469,0,0,0-.469-.469h-4.828a.469.469,0,0,0,0,.938h4.828A.469.469,0,0,0,112.225,200.469Z" transform="translate(-104.587 -195.313)" fill="#96a5ff"/>
        <path class="writing-fill" data-name="Path 132" d="M106.928,280a.469.469,0,0,0,0,.938h2.932a.469.469,0,0,0,0-.937Z" transform="translate(-104.587 -273.438)" fill="#96a5ff"/>
        <path class="writing-fill" data-name="Path 133" d="M30.013,11.063H28.445a.939.939,0,0,1-.937-.937V1.875a.939.939,0,0,1,.938-.937h5.763a.939.939,0,0,1,.938.938V4.758a.469.469,0,0,0,.938,0V1.875A1.877,1.877,0,0,0,34.208,0H28.445A1.877,1.877,0,0,0,26.57,1.875v8.25A1.877,1.877,0,0,0,28.445,12h1.568a.469.469,0,1,0,0-.937Z" transform="translate(-26.57)" fill="#96a5ff"/>
        <path class="writing-fill" data-name="Path 134" d="M248.717,272.435a1.408,1.408,0,0,0-1.988,0L244.155,275a.469.469,0,0,0-.117.2l-.56,1.845a.469.469,0,0,0,.574.588l1.892-.524a.468.468,0,0,0,.206-.12l2.568-2.563A1.408,1.408,0,0,0,248.717,272.435Zm-3.143,3.8-.952.264.279-.917,1.736-1.733.663.663Zm2.481-2.476-.091.091-.663-.663.091-.09a.469.469,0,0,1,.663.663Z" transform="translate(-238.374 -265.649)" fill="#96a5ff"/>
        <path class="writing-fill" data-name="Path 135" d="M111.756,120h-4.828a.469.469,0,0,0,0,.938h4.828a.469.469,0,0,0,0-.937Z" transform="translate(-104.587 -117.188)" fill="#96a5ff"/>
      </g>
    </g>
  </g>
</svg>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class  extends Vue {}
</script>

<style scoped lang="scss">
</style>
