<template>
<svg id="menu" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14">
  <g id="Group_137" data-name="Group 137">
    <g id="Group_136" data-name="Group 136">
      <path id="Path_126" data-name="Path 126" d="M4.834,0H1.619A1.621,1.621,0,0,0,0,1.619V4.834A1.621,1.621,0,0,0,1.619,6.453H4.834A1.621,1.621,0,0,0,6.453,4.834V1.619A1.621,1.621,0,0,0,4.834,0Zm.525,4.834a.526.526,0,0,1-.525.525H1.619a.526.526,0,0,1-.525-.525V1.619a.526.526,0,0,1,.525-.525H4.834a.526.526,0,0,1,.525.525Z" fill="#ff6956"/>
    </g>
  </g>
  <g id="Group_139" data-name="Group 139" transform="translate(7.547)">
    <g id="Group_138" data-name="Group 138">
      <path id="Path_127" data-name="Path 127" d="M280.813,0h-3.172A1.642,1.642,0,0,0,276,1.641V4.813a1.642,1.642,0,0,0,1.641,1.641h3.172a1.642,1.642,0,0,0,1.641-1.641V1.641A1.642,1.642,0,0,0,280.813,0Zm.547,4.813a.547.547,0,0,1-.547.547h-3.172a.547.547,0,0,1-.547-.547V1.641a.547.547,0,0,1,.547-.547h3.172a.547.547,0,0,1,.547.547Z" transform="translate(-276)" fill="#ff6956"/>
    </g>
  </g>
  <g id="Group_141" data-name="Group 141" transform="translate(0 7.547)">
    <g id="Group_140" data-name="Group 140">
      <path id="Path_128" data-name="Path 128" d="M4.834,276H1.619A1.621,1.621,0,0,0,0,277.619v3.215a1.621,1.621,0,0,0,1.619,1.619H4.834a1.621,1.621,0,0,0,1.619-1.619v-3.215A1.621,1.621,0,0,0,4.834,276Zm.525,4.834a.526.526,0,0,1-.525.525H1.619a.526.526,0,0,1-.525-.525v-3.215a.526.526,0,0,1,.525-.525H4.834a.526.526,0,0,1,.525.525Z" transform="translate(0 -276)" fill="#ff6956"/>
    </g>
  </g>
  <g id="Group_143" data-name="Group 143" transform="translate(7.547 7.547)">
    <g id="Group_142" data-name="Group 142">
      <path id="Path_129" data-name="Path 129" d="M280.813,276h-3.172A1.642,1.642,0,0,0,276,277.641v3.172a1.642,1.642,0,0,0,1.641,1.641h3.172a1.642,1.642,0,0,0,1.641-1.641v-3.172A1.642,1.642,0,0,0,280.813,276Zm.547,4.813a.547.547,0,0,1-.547.547h-3.172a.547.547,0,0,1-.547-.547v-3.172a.547.547,0,0,1,.547-.547h3.172a.547.547,0,0,1,.547.547Z" transform="translate(-276 -276)" fill="#ff6956"/>
    </g>
  </g>
</svg>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class Menu extends Vue {}
</script>

<style scoped lang="scss">
</style>
