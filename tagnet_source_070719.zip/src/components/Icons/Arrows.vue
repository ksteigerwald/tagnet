<template>
<svg xmlns="http://www.w3.org/2000/svg" width="14.4" height="16.09" viewBox="0 0 14.4 16.09">
  <g id="Arrows-2" transform="translate(0)">
    <path id="Path_121" data-name="Path 121" d="M14.47,3.993a.721.721,0,0,0,.211.509.649.649,0,0,0,.961,0l1.83-1.893V13.6a.721.721,0,0,0,1.441,0V2.451l1.922,2.027a.759.759,0,0,0,1.047.038A.721.721,0,0,0,21.94,3.5L19.058.376a.7.7,0,0,0-.629-.211.711.711,0,0,0-.644.192L14.662,3.479A.716.716,0,0,0,14.47,3.993Z" transform="translate(-7.724 -0.15)" fill="#ff6956" fill-rule="evenodd"/>
    <path id="Path_122" data-name="Path 122" d="M4.172,18.563a.716.716,0,0,0,.639-.183l3.123-3a.721.721,0,0,0,0-1.019.8.8,0,0,0-1.081,0L4.888,16.19V5.371a.721.721,0,1,0-1.441,0V16.281L1.636,14.254a.687.687,0,0,0-.99-.038.706.706,0,0,0-.216.528.725.725,0,0,0,.2.48l2.883,3.123A.716.716,0,0,0,4.172,18.563Z" transform="translate(-0.429 -2.488)" fill="#ff6956" fill-rule="evenodd"/>
  </g>
</svg>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class Arrow extends Vue {}
</script>

<style scoped lang="scss">
</style>
