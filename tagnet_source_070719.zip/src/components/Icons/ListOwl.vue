<template>
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
  <g id="list-owl" transform="translate(-0.001)">
    <g id="Group_44" data-name="Group 44" transform="translate(0.001)">
      <path class="goal-fill" data-name="Path 45" d="M12,0A12,12,0,1,0,24,12,12,12,0,0,0,12,0ZM7.226,16.357a.829.829,0,1,1,.829-.829A.828.828,0,0,1,7.226,16.357Zm0-3.528A.829.829,0,1,1,8.055,12,.829.829,0,0,1,7.226,12.829Zm0-3.528a.829.829,0,1,1,.829-.829A.828.828,0,0,1,7.226,9.3Zm10.378,7H9.833a.83.83,0,0,1,0-1.66H17.6a.83.83,0,1,1,0,1.66Zm0-3.5H9.833a.83.83,0,0,1,0-1.66H17.6a.83.83,0,1,1,0,1.66Zm0-3.5H9.833a.83.83,0,0,1,0-1.66H17.6a.83.83,0,0,1,0,1.66Z" transform="translate(-0.001)" fill="#dbb7ff"/>
    </g>
  </g>
</svg>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class ListOwl extends Vue {}
</script>

<style scoped lang="scss">
</style>
