<template>
<svg id="Group_154" data-name="Group 154" xmlns="http://www.w3.org/2000/svg" width="16" height="13" viewBox="0 0 16 13">
  <path id="Path_130" data-name="Path 130" d="M14,5V3H0V14a1.959,1.959,0,0,0,2,2H14.5s1.5-.031,1.5-2V5ZM2,15a.979.979,0,0,1-1-1V4H13V14a1.446,1.446,0,0,0,.338,1Z" transform="translate(0 -3)" fill="#dbb7ff"/>
  <rect id="Rectangle_171" data-name="Rectangle 171" width="10" height="1" transform="translate(2 3)" fill="#dbb7ff"/>
  <rect id="Rectangle_172" data-name="Rectangle 172" width="3.5" height="1" transform="translate(7.5 9)" fill="#dbb7ff"/>
  <rect id="Rectangle_173" data-name="Rectangle 173" width="4.5" height="1" transform="translate(7.5 7)" fill="#dbb7ff"/>
  <rect id="Rectangle_174" data-name="Rectangle 174" width="4.5" height="1" transform="translate(7.5 5)" fill="#dbb7ff"/>
  <rect id="Rectangle_175" data-name="Rectangle 175" width="4.5" height="5" transform="translate(2 5)" fill="#dbb7ff"/>
</svg>

</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class Topic extends Vue {}
</script>

<style scoped lang="scss">
</style>
