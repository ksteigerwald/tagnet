<template>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="11.138" viewBox="0 0 20 11.138">
  <path class="goal-fill" data-name="Path 147" d="M5.241,20.6a1.026,1.026,0,0,1,.262-.916l4.306-4.478A1.033,1.033,0,1,1,11.3,16.64L8.672,19.4H24.187a1.033,1.033,0,1,1,0,2.067H8.541l2.9,2.659a1.033,1.033,0,1,1-1.378,1.516L5.586,21.5A1.013,1.013,0,0,1,5.241,20.6Z" transform="translate(-5.22 -14.868)" fill="#ff6956" fill-rule="evenodd"/>
</svg>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class BackArrow extends Vue {}
</script>

<style scoped lang="scss">
</style>
