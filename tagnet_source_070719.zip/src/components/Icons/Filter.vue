<template>
<svg xmlns="http://www.w3.org/2000/svg" width="14.4" height="13.273" viewBox="0 0 14.4 13.273">
  <path class="goal-fill" d="M14.358,9.933a.436.436,0,0,0-.395-.25H.436A.436.436,0,0,0,.1,10.4L5.3,16.7V22.52a.436.436,0,0,0,.63.391l2.922-1.448a.436.436,0,0,0,.243-.39L9.1,16.7,14.3,10.4A.436.436,0,0,0,14.358,9.933ZM8.327,16.27a.436.436,0,0,0-.1.277L8.221,20.8,6.172,21.816V16.547a.436.436,0,0,0-.1-.278L1.361,10.556H13.038Z" transform="translate(0 -9.683)" fill="#ff6956"/>
</svg>
</template>

<script lang="ts">
import { Component, Prop, Vue } from 'vue-property-decorator';

@Component
export default class FilterToggle extends Vue {}
</script>

<style scoped lang="scss">
</style>
