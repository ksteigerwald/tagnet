const typeDefs = `
  type MetaCheck {
    check: String
  }
`;

export default typeDefs;