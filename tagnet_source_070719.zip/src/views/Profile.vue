<template>
    <div class="profile">
        <div class="profile__container">
            <div class="profile__left">
                <div class="profile__user">
                    <div v-if="photo" class="profile__user-photo">
                        <img :src="photo" alt="">
                    </div>
                    <div class="profile__user-info">
                        <p>John Doe</p><span>Software Engineer</span>
                    </div>
                </div>
                <div class="profile__menu">
                    <ul class="profile__tab">
                        <li class="profile__tab-item"><a @click.prevent href="#"><span><svg
                                xmlns="http://www.w3.org/2000/svg"
                                xmlns:xlink="http://www.w3.org/1999/xlink"
                                width="20px" height="20px" viewBox="0 0 20 20">
    <path fill-rule="evenodd"  fill="rgb(26, 26, 26)"
          d="M4.500,9.500 L5.900,8.100 L8.999,11.200 L17.600,2.600 L19.000,4.000 L8.999,14.000 L4.500,9.500 ZM10.000,2.000 C5.600,2.000 2.000,5.600 2.000,10.000 C2.000,14.400 5.600,18.000 10.000,18.000 C14.400,18.000 18.000,14.400 18.000,10.000 L20.000,10.000 C20.000,15.500 15.500,20.000 10.000,20.000 C4.500,20.000 -0.000,15.500 -0.000,10.000 C-0.000,4.500 4.500,-0.000 10.000,-0.000 C11.300,-0.000 12.600,0.300 13.800,0.700 L12.200,2.300 C11.500,2.100 10.800,2.000 10.000,2.000 Z"/>
</svg></span>
                            <p>Activity Log</p></a></li>
                        <li class="profile__tab-item profile__tab-item--active"><a @click.prevent href="#"><span><svg
                                xmlns="http://www.w3.org/2000/svg"
                                xmlns:xlink="http://www.w3.org/1999/xlink"
                                width="24px" height="24px" viewBox="0 0 24 24">
    <path fill-rule="evenodd"  fill="rgb(255, 105, 86)"
          d="M22.761,14.519 L21.077,14.800 C20.906,15.361 20.676,15.908 20.400,16.434 L21.392,17.828 C21.813,18.419 21.744,19.227 21.232,19.738 L19.738,21.232 C19.457,21.513 19.086,21.668 18.690,21.668 C18.379,21.668 18.079,21.573 17.828,21.393 L16.439,20.400 C15.918,20.676 15.372,20.901 14.805,21.077 L14.519,22.761 C14.399,23.478 13.782,24.000 13.055,24.000 L10.939,24.000 C10.212,24.000 9.595,23.478 9.475,22.761 L9.195,21.077 C8.648,20.906 8.117,20.691 7.611,20.425 L6.201,21.428 C5.951,21.608 5.655,21.703 5.344,21.703 C4.948,21.703 4.577,21.548 4.296,21.267 L2.802,19.773 C2.286,19.262 2.221,18.455 2.642,17.863 L3.629,16.490 C3.349,15.968 3.118,15.422 2.943,14.860 L1.238,14.569 C0.521,14.449 -0.000,13.832 -0.000,13.105 L-0.000,10.995 C-0.000,10.268 0.521,9.651 1.238,9.531 L2.903,9.250 C3.073,8.683 3.293,8.137 3.569,7.610 L2.567,6.202 C2.146,5.610 2.216,4.803 2.727,4.291 L4.226,2.798 C4.502,2.517 4.878,2.361 5.274,2.361 C5.585,2.361 5.886,2.457 6.136,2.637 L7.515,3.630 C8.037,3.349 8.583,3.118 9.144,2.943 L9.435,1.238 C9.556,0.521 10.172,-0.000 10.899,-0.000 L13.010,-0.000 C13.737,-0.000 14.353,0.521 14.474,1.238 L14.754,2.903 C15.341,3.078 15.908,3.314 16.449,3.600 L17.843,2.607 C18.094,2.426 18.389,2.331 18.700,2.331 C19.096,2.331 19.468,2.487 19.748,2.767 L21.242,4.261 C21.758,4.773 21.824,5.580 21.403,6.171 L20.410,7.560 C20.686,8.082 20.911,8.628 21.087,9.195 L22.771,9.481 C23.488,9.601 24.010,10.218 23.999,10.945 L23.999,13.055 C23.999,13.782 23.478,14.399 22.761,14.519 ZM22.661,10.945 C22.661,10.879 22.616,10.824 22.551,10.814 L20.445,10.458 C20.184,10.418 19.969,10.222 19.903,9.962 C19.713,9.225 19.422,8.518 19.031,7.861 C18.896,7.631 18.906,7.340 19.061,7.124 L20.299,5.384 C20.335,5.329 20.329,5.259 20.285,5.214 L18.791,3.720 C18.755,3.685 18.715,3.680 18.695,3.680 C18.670,3.680 18.645,3.690 18.620,3.705 L16.891,4.948 C16.670,5.103 16.384,5.114 16.153,4.978 C15.481,4.582 14.760,4.287 14.003,4.096 C13.742,4.031 13.546,3.815 13.501,3.550 L13.150,1.459 C13.140,1.394 13.085,1.348 13.020,1.348 L10.909,1.348 C10.844,1.348 10.789,1.394 10.779,1.459 L10.418,3.579 C10.373,3.840 10.177,4.051 9.922,4.121 C9.185,4.312 8.477,4.612 7.826,5.003 C7.595,5.139 7.305,5.129 7.084,4.973 L5.354,3.740 C5.334,3.725 5.309,3.715 5.279,3.715 C5.254,3.715 5.219,3.720 5.184,3.755 L3.690,5.249 C3.645,5.294 3.640,5.369 3.675,5.419 L4.923,7.174 C5.078,7.390 5.094,7.676 4.958,7.906 C4.572,8.563 4.286,9.275 4.101,10.012 C4.036,10.272 3.820,10.468 3.554,10.513 L1.464,10.864 C1.399,10.874 1.353,10.929 1.353,10.995 L1.353,13.105 C1.353,13.170 1.399,13.225 1.464,13.236 L3.584,13.597 C3.845,13.642 4.056,13.837 4.126,14.093 C4.316,14.830 4.617,15.537 5.008,16.189 C5.144,16.419 5.134,16.710 4.978,16.930 L3.745,18.660 C3.710,18.715 3.715,18.786 3.760,18.831 L5.254,20.325 C5.289,20.360 5.329,20.365 5.349,20.365 C5.374,20.365 5.400,20.355 5.425,20.340 L7.179,19.092 C7.294,19.006 7.435,18.966 7.570,18.966 C7.685,18.966 7.806,18.996 7.911,19.056 C8.558,19.427 9.250,19.713 9.967,19.899 C10.222,19.964 10.418,20.174 10.463,20.440 L10.814,22.546 C10.824,22.611 10.879,22.656 10.945,22.656 L13.055,22.656 C13.120,22.656 13.175,22.611 13.185,22.546 L13.541,20.440 C13.582,20.179 13.777,19.964 14.038,19.899 C14.775,19.708 15.481,19.417 16.138,19.026 C16.369,18.891 16.660,18.901 16.875,19.056 L18.615,20.295 C18.635,20.310 18.660,20.320 18.690,20.320 C18.715,20.320 18.750,20.315 18.785,20.280 L20.280,18.786 C20.325,18.741 20.329,18.665 20.294,18.615 L19.056,16.870 C18.901,16.650 18.891,16.364 19.026,16.133 C19.417,15.477 19.708,14.770 19.898,14.033 C19.964,13.777 20.174,13.582 20.440,13.537 L22.546,13.186 C22.611,13.175 22.656,13.120 22.656,13.055 L22.661,13.055 L22.661,10.945 Z"/>
    <path fill-rule="evenodd"  fill="rgb(255, 105, 86)"
          d="M12.002,17.176 C9.144,17.176 6.823,14.855 6.823,11.997 C6.823,9.140 9.144,6.818 12.002,6.818 C14.860,6.818 17.181,9.140 17.181,11.997 C17.181,14.855 14.860,17.176 12.002,17.176 ZM12.002,8.172 C9.891,8.172 8.177,9.886 8.177,11.997 C8.177,14.108 9.891,15.823 12.002,15.823 C14.113,15.823 15.828,14.108 15.828,11.997 C15.828,9.886 14.113,8.172 12.002,8.172 Z"/>
</svg></span>
                            <p>Setting</p></a></li>
                    </ul>
                    <a class="profile__logout" @click.prevent="logout" href="#"><span>
                            <img src="assets/images/profile/logout.png" alt=""></span>
                        <p>Logout</p>
                    </a>
                </div>
            </div>
            <div class="profile__right">
                <div class="profile__block">
                    <div class="profile__title">
                        <p>Profiles</p>
                    </div>
                    <div class="profile__input">
                        <div class="input">
                            <label for="name">Name</label>
                            <input type="text" id="name" disabled value="John Doe">
                        </div>
                        <div class="input">
                            <label for="bio">Bio</label>
                            <input type="text" id="bio" disabled value="Software Engineer">
                        </div>
                        <a class="link" @click.prevent href="#"><span>Change Avatar</span></a>
                    </div>
                    <div class="profile__action">
                        <a @click.prevent href="#"><span>Update profile</span></a>
                    </div>
                </div>
                <div class="profile__block">
                    <div class="profile__title">
                        <p>Account Details</p>
                    </div>
                    <div class="profile__input">
                        <div class="input">
                            <label for="email">Email</label>
                            <input type="text" id="email" disabled value="johndoe@gmail.com">
                        </div>
                        <a class="link" @click.prevent href="#"><span>Change Password</span></a>
                        <a class="link" @click.prevent href="#"><span>Change Language</span></a>
                    </div>
                    <div class="profile__action">
                        <a @click.prevent href="#"><span>Update changes</span></a>
                    </div>
                </div>
            </div>
            <div class="profile__footer">
                <ul class="profile__footer-menu">
                    <li class="profile__footer-item"><span>© 2019 Tagnet. All Right Reserved</span></li>
                    <li class="profile__footer-item"><a @click.prevent href="#"><span>Terms and condition</span></a></li>
                    <li class="profile__footer-item"><a @click.prevent href="#"><span>Privacy policy</span></a></li>
                </ul>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
    import { Component, Prop, Vue } from 'vue-property-decorator';
    import { State, Getter, Action, namespace } from 'vuex-class';

    @Component({
        components: {}
    })
    export default class Profile extends Vue {
        photo: string = localStorage.getItem('TAGNET-picture');

        static logout() {
            window.localStorage.removeItem('TAGNET-picture');
            window.localStorage.removeItem('TAGNET-user');
            window.location.replace("/");
        }

    };
</script>

