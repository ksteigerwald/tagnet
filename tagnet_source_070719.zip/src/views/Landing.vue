<template>
    <div>
    <div class="content">
      <div class="top">
        <div class="top__background">
          <div class="top__background-left"></div>
          <div class="top__background-right"></div>
        </div>
        <div class="top__container">
          <div class="top__title">
            <h1>The best way </br> to organize your digital
self</h1>
          </div>
          <div class="top__input">
            <div class="create-input">
              <div class="create-input__left">
                <div class="create-input__icon"><svg
        xmlns="http://www.w3.org/2000/svg"
        xmlns:xlink="http://www.w3.org/1999/xlink"
        width="30px" height="31px" viewBox="0 0 30 31">
    <path fill-rule="evenodd"  fill="rgb(195, 195, 195)"
          d="M14.729,23.071 C13.300,23.071 11.964,22.671 10.824,21.979 L5.666,27.137 C4.718,26.397 3.866,25.543 3.125,24.596 L5.695,22.026 L8.283,19.438 C7.589,18.298 7.190,16.961 7.190,15.533 C7.190,11.376 10.571,7.994 14.729,7.994 C18.885,7.994 22.268,11.376 22.268,15.533 C22.268,19.689 18.887,23.071 14.729,23.071 ZM14.729,11.587 C12.550,11.587 10.785,13.353 10.785,15.531 C10.785,17.709 12.551,19.475 14.729,19.475 C16.907,19.475 18.673,17.709 18.673,15.531 C18.673,13.353 16.907,11.587 14.729,11.587 Z"/>
    <path fill-rule="evenodd"  fill="rgb(195, 195, 195)"
          d="M14.729,0.803 C6.595,0.803 -0.000,7.397 -0.000,15.532 C-0.000,18.953 1.169,22.097 3.123,24.596 L5.690,22.029 L5.693,22.026 C4.957,21.004 4.390,19.856 4.031,18.617 C4.025,18.594 4.018,18.571 4.012,18.550 C3.978,18.431 3.945,18.309 3.916,18.187 C3.908,18.152 3.900,18.116 3.892,18.082 C3.849,17.903 3.812,17.722 3.778,17.540 C3.763,17.458 3.747,17.375 3.733,17.290 C3.721,17.216 3.711,17.143 3.702,17.068 C3.689,16.969 3.676,16.871 3.665,16.771 C3.657,16.703 3.650,16.634 3.644,16.566 C3.634,16.452 3.624,16.338 3.618,16.225 C3.614,16.168 3.610,16.112 3.608,16.055 C3.600,15.883 3.595,15.709 3.595,15.534 C3.595,15.366 3.600,15.199 3.608,15.031 C3.870,9.127 8.753,4.405 14.721,4.400 C14.724,4.400 14.726,4.400 14.729,4.400 C20.869,4.400 25.863,9.395 25.863,15.534 C25.863,15.536 25.863,15.537 25.863,15.539 C25.861,21.510 21.134,26.394 15.227,26.657 C15.061,26.663 14.896,26.670 14.729,26.670 C13.664,26.670 12.634,26.518 11.658,26.237 L11.228,26.667 L8.854,29.041 C10.654,29.826 12.640,30.265 14.729,30.265 C22.863,30.265 29.458,23.672 29.458,15.536 C29.456,7.397 22.863,0.803 14.729,0.803 Z"/>
</svg>
                </div>
                <div class="create-input__input">
                  <input type="text" placeholder="This text will be animated like it was typing">
                </div>
              </div>
              <div class="create-input__right"><a class="create-input__button" @click.prevent href="#">
                  <p>Create</p><span><svg
        xmlns="http://www.w3.org/2000/svg"
        xmlns:xlink="http://www.w3.org/1999/xlink"
        width="24px" height="24px"
        viewBox="0 0 24 24"
>
    <path fill-rule="evenodd"  opacity="0.2" fill="rgb(255, 105, 86)"
          d="M12.000,24.000 C5.364,24.000 -0.000,18.636 -0.000,12.000 C-0.000,5.364 5.364,-0.000 12.000,-0.000 C18.636,-0.000 24.000,5.364 24.000,12.000 C24.000,18.636 18.636,24.000 12.000,24.000 Z"/>
    <path fill-rule="evenodd"  fill="rgb(255, 105, 86)"
          d="M6.000,18.000 L20.000,12.000 L6.000,6.000 L6.000,10.666 L16.000,12.000 L6.000,13.333 L6.000,18.000 Z"/>
</svg></span></a></div>
            </div>
          </div>
          <div class="top__links">
            <ul class="links">
              <li class="links__item"><a @click.prevent href="#"><span class="links__icon links__icon--get"></span><span class="links__text">Get started</span></a></li>
              <li class="links__item"><a @click.prevent href="#"><span class="links__icon links__icon--play"></span><span class="links__text">How it works</span></a></li>
            </ul>
          </div>
          <div class="top__companies">
            <div class="companies">
              <div class="companies__title">
                <p>Leading companies trusts us</p>
              </div>
              <ul class="companies__list">
                <li class="companies__item"><img src="../assets/images/companies/1.png" alt=""></li>
                <li class="companies__item"><img src="../assets/images/companies/2.png" alt=""></li>
                <li class="companies__item"><img src="../assets/images/companies/3.png" alt=""></li>
                <li class="companies__item"><img src="../assets/images/companies/4.png" alt=""></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="info">
        <div class="info__container">
          <div class="info__title">
            <p>Designed for professionals<br> to be more productive</p>
          </div>
          <ul class="info__list">
            <li class="info__item">
              <div class="info__item-icon"><svg
        xmlns="http://www.w3.org/2000/svg"
        xmlns:xlink="http://www.w3.org/1999/xlink"
        width="25px" height="27px" vieBox="0 0 25 27">
    <path fill-rule="evenodd"  fill="rgb(255, 105, 86)"
          d="M24.576,26.086 C24.321,26.331 23.985,26.466 23.631,26.466 C23.257,26.466 22.908,26.317 22.648,26.048 L16.440,19.591 C14.677,20.830 12.615,21.483 10.452,21.483 C4.689,21.483 -0.000,16.794 -0.000,11.030 C-0.000,5.267 4.689,0.578 10.452,0.578 C16.215,0.578 20.904,5.267 20.904,11.030 C20.904,13.497 20.036,15.867 18.452,17.750 L24.614,24.158 C25.135,24.700 25.118,25.564 24.576,26.086 ZM10.452,3.305 C6.192,3.305 2.727,6.770 2.727,11.030 C2.727,15.290 6.192,18.756 10.452,18.756 C14.712,18.756 18.178,15.290 18.178,11.030 C18.178,6.770 14.712,3.305 10.452,3.305 Z"/>
</svg>
              </div>
              <div class="info__item-text"><span>Search</span>
                <p>Find what you are looking for using simple or complex expressions to dig it up.</p>
              </div>
            </li>
            <li class="info__item">
              <div class="info__item-icon"><svg
        xmlns="http://www.w3.org/2000/svg"
        xmlns:xlink="http://www.w3.org/1999/xlink"
        width="40px" height="27px"
        viewBox="0 0 40 27"
>
    <path fill-rule="evenodd"  fill="rgb(255, 105, 86)"
          d="M39.697,23.950 C39.553,23.804 39.368,23.732 39.142,23.732 L15.983,23.732 C15.758,23.732 15.573,23.805 15.428,23.950 C15.284,24.094 15.212,24.279 15.212,24.504 L15.212,26.048 C15.212,26.273 15.284,26.458 15.428,26.603 C15.573,26.747 15.758,26.820 15.983,26.820 L39.142,26.820 C39.368,26.820 39.553,26.747 39.697,26.603 C39.841,26.458 39.914,26.273 39.914,26.048 L39.914,24.504 C39.914,24.279 39.842,24.094 39.697,23.950 Z"/>
    <path fill-rule="evenodd"  fill="rgb(255, 105, 86)"
          d="M2.643,1.128 C2.482,0.967 2.297,0.886 2.088,0.886 C1.878,0.886 1.694,0.967 1.533,1.128 L0.327,2.334 C0.166,2.495 0.086,2.680 0.086,2.889 C0.086,3.098 0.166,3.283 0.327,3.444 L9.808,12.924 L0.327,22.405 C0.166,22.566 0.086,22.751 0.086,22.960 C0.086,23.169 0.166,23.354 0.327,23.515 L1.533,24.721 C1.694,24.882 1.878,24.962 2.088,24.962 C2.296,24.962 2.482,24.882 2.643,24.721 L13.885,13.479 C14.045,13.318 14.125,13.133 14.125,12.924 C14.125,12.715 14.045,12.530 13.885,12.370 L2.643,1.128 Z"/>
</svg>
              </div>
              <div class="info__item-text"><span>Create</span>
                <p>Presents you with a menu to create a Memorandum, such as Goal, Event, Idea, Any, Topic, or Person.</p>
              </div>
            </li>
            <li class="info__item">
              <div class="info__item-icon"><span>@</span></div>
              <div class="info__item-text"><span>Append</span>
                <p>Entering '@' pulls up all of your Memos, Entries today consist of text, it can be plain text with a hyperlink embedded or an image.</p>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div class="blocks">
        <div class="block">
          <div class="block__container">
            <div class="block__content">
              <div class="block__title">
                <p>Better <br> bookmark tool</p>
              </div>
              <div class="block__text">
                <p>Log bookmark links by category, or drop them into a Bookmark bucket. Tagnet.io gives you the ability to find that one website you looked at years ago.</p>
              </div>
            </div>
            <div class="block__image"><img src="../assets/images/blocks/1.png" alt=""></div>
          </div>
        </div>
        <div class="block block--image-first">
          <div class="block__container">
            <div class="block__image"><img src="../assets/images/blocks/2.png" alt=""></div>
            <div class="block__content block__content--right">
              <div class="block__title">
                <p>Note taking</p>
              </div>
              <div class="block__text">
                <p>Log a quick note, pull it up from any device or computer. Taganet.io is the way for you to get an idea down fast and then pull it up whenever you need it. </p>
              </div>
            </div>
          </div>
        </div>
        <!--
        <div class="block">
          <div class="block__container">
            <div class="block__content">
              <div class="block__title">
                <p>Goal Tracking</p>
              </div>
              <div class="block__text">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut iaculis eget sapien eu vehicula. Morbi vitae est sit amet est efficitur semper vehicula.</p>
              </div>
            </div>
            <div class="block__image"><img src="../assets/images/blocks/3.png" alt=""></div>
          </div>
        </div>
        -->
        <div class="block block--image-first">
          <div class="block__container">
            <div class="block__image"><img src="../assets/images/blocks/4.png" alt=""></div>
            <div class="block__content block__content--right">
              <div class="block__title">
                <p>Todo List</p>
              </div>
              <div class="block__text">
                <p>Create a ToDo and categorize them under one of your buckets. Tagnet has lots of little apps built in to make you more productive. </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--
      <div class="testimonials">
        <div class="testimonials__container">
          <div class="testimonials__persons">
            <div class="testimonials__image"><img src="../assets/images/testimonials/1.png"></div>
            <div class="testimonials__image testimonials__image--center"><img src="../assets/images/testimonials/2.png"></div>
            <div class="testimonials__image"><img src="../assets/images/testimonials/3.png"></div>
          </div>
          <div class="testimonials__content">
            <div class="testimonials__title">
              <p>John Doe, Netflix</p>
            </div>
            <div class="testimonials__text">
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut iaculis eget sapien eu vehicula. Morbi vitae est sit amet est efficitur semper vehicula vitae tellus. Nullam id turpis consectetur, iaculis quam in, tempus risus.</p>
            </div>
          </div>
        </div>
      </div> -->
      <div class="sing">
        <div class="sing__container">
          <div class="sing__ball-left"></div>
          <div class="sing__ball-right"></div>
          <div class="sing__center">
            <div class="create-input">
              <div class="create-input__left">
                <div class="create-input__icon"><svg
        xmlns="http://www.w3.org/2000/svg"
        xmlns:xlink="http://www.w3.org/1999/xlink"
        width="30px" height="31px" viewBox="0 0 30 31">
    <path fill-rule="evenodd"  fill="rgb(195, 195, 195)"
          d="M14.729,23.071 C13.300,23.071 11.964,22.671 10.824,21.979 L5.666,27.137 C4.718,26.397 3.866,25.543 3.125,24.596 L5.695,22.026 L8.283,19.438 C7.589,18.298 7.190,16.961 7.190,15.533 C7.190,11.376 10.571,7.994 14.729,7.994 C18.885,7.994 22.268,11.376 22.268,15.533 C22.268,19.689 18.887,23.071 14.729,23.071 ZM14.729,11.587 C12.550,11.587 10.785,13.353 10.785,15.531 C10.785,17.709 12.551,19.475 14.729,19.475 C16.907,19.475 18.673,17.709 18.673,15.531 C18.673,13.353 16.907,11.587 14.729,11.587 Z"/>
    <path fill-rule="evenodd"  fill="rgb(195, 195, 195)"
          d="M14.729,0.803 C6.595,0.803 -0.000,7.397 -0.000,15.532 C-0.000,18.953 1.169,22.097 3.123,24.596 L5.690,22.029 L5.693,22.026 C4.957,21.004 4.390,19.856 4.031,18.617 C4.025,18.594 4.018,18.571 4.012,18.550 C3.978,18.431 3.945,18.309 3.916,18.187 C3.908,18.152 3.900,18.116 3.892,18.082 C3.849,17.903 3.812,17.722 3.778,17.540 C3.763,17.458 3.747,17.375 3.733,17.290 C3.721,17.216 3.711,17.143 3.702,17.068 C3.689,16.969 3.676,16.871 3.665,16.771 C3.657,16.703 3.650,16.634 3.644,16.566 C3.634,16.452 3.624,16.338 3.618,16.225 C3.614,16.168 3.610,16.112 3.608,16.055 C3.600,15.883 3.595,15.709 3.595,15.534 C3.595,15.366 3.600,15.199 3.608,15.031 C3.870,9.127 8.753,4.405 14.721,4.400 C14.724,4.400 14.726,4.400 14.729,4.400 C20.869,4.400 25.863,9.395 25.863,15.534 C25.863,15.536 25.863,15.537 25.863,15.539 C25.861,21.510 21.134,26.394 15.227,26.657 C15.061,26.663 14.896,26.670 14.729,26.670 C13.664,26.670 12.634,26.518 11.658,26.237 L11.228,26.667 L8.854,29.041 C10.654,29.826 12.640,30.265 14.729,30.265 C22.863,30.265 29.458,23.672 29.458,15.536 C29.456,7.397 22.863,0.803 14.729,0.803 Z"/>
</svg>
                </div>
                <div class="create-input__input">
                  <input type="text" disabled placeholder="" value="Try Tagnet for free now">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <footer class="footer">
        <ul class="footer__menu">
          <li class="footer__menu-item"><a @click.prevent href="#">About Tagnet</a></li>
          <li class="footer__menu-item"><router-link to="/register" href="#">Register</router-link></li>
          <li class="footer__menu-item"><a @click.prevent href="#">Help</a></li>
          <li class="footer__menu-item"><a @click.prevent href="#">Contact Us</a></li>
        </ul>
        <ul class="footer__social">
          <li class="footer__social-item"><a @click.prevent href="#"><svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="169.063px" height="169.063px" viewBox="0 0 169.063 169.063" style="enable-background:new 0 0 169.063 169.063;"
	 xml:space="preserve">
<g>
	<path d="M122.406,0H46.654C20.929,0,0,20.93,0,46.655v75.752c0,25.726,20.929,46.655,46.654,46.655h75.752
		c25.727,0,46.656-20.93,46.656-46.655V46.655C169.063,20.93,148.133,0,122.406,0z M154.063,122.407
		c0,17.455-14.201,31.655-31.656,31.655H46.654C29.2,154.063,15,139.862,15,122.407V46.655C15,29.201,29.2,15,46.654,15h75.752
		c17.455,0,31.656,14.201,31.656,31.655V122.407z"/>
	<path d="M84.531,40.97c-24.021,0-43.563,19.542-43.563,43.563c0,24.02,19.542,43.561,43.563,43.561s43.563-19.541,43.563-43.561
		C128.094,60.512,108.552,40.97,84.531,40.97z M84.531,113.093c-15.749,0-28.563-12.812-28.563-28.561
		c0-15.75,12.813-28.563,28.563-28.563s28.563,12.813,28.563,28.563C113.094,100.281,100.28,113.093,84.531,113.093z"/>
	<path d="M129.921,28.251c-2.89,0-5.729,1.17-7.77,3.22c-2.051,2.04-3.23,4.88-3.23,7.78c0,2.891,1.18,5.73,3.23,7.78
		c2.04,2.04,4.88,3.22,7.77,3.22c2.9,0,5.73-1.18,7.78-3.22c2.05-2.05,3.22-4.89,3.22-7.78c0-2.9-1.17-5.74-3.22-7.78
		C135.661,29.421,132.821,28.251,129.921,28.251z"/>
</g>
</svg>
</a></li>
          <li class="footer__social-item"><a @click.prevent href="#"><svg
        xmlns="http://www.w3.org/2000/svg"
        xmlns:xlink="http://www.w3.org/1999/xlink"
        width="13px" height="12px"
        viewBox="0 0 13 12"
>
    <path fill-rule="evenodd"  fill="rgb(150, 165, 255)"
          d="M12.278,-0.000 L1.252,-0.000 C0.990,-0.000 0.765,0.225 0.765,0.487 L0.765,11.475 C0.765,11.775 0.990,12.000 1.252,12.000 L7.140,12.000 L7.140,7.500 L5.640,7.500 L5.640,5.625 L7.140,5.625 L7.140,4.125 C7.140,2.587 8.115,1.800 9.503,1.800 C10.178,1.800 10.740,1.875 10.890,1.875 L10.890,3.487 L9.915,3.487 C9.165,3.487 8.978,3.862 8.978,4.387 L8.978,5.625 L10.853,5.625 L10.478,7.500 L8.978,7.500 L9.015,12.000 L12.240,12.000 C12.503,12.000 12.728,11.775 12.728,11.512 L12.728,0.487 C12.765,0.225 12.540,-0.000 12.278,-0.000 Z"/>
</svg></a></li>
          <li class="footer__social-item"><a @click.prevent href="#"><svg
        xmlns="http://www.w3.org/2000/svg"
        xmlns:xlink="http://www.w3.org/1999/xlink"
        width="16px" height="12px"
        viewBox="0 0 16 12"
>
    <path fill-rule="evenodd"  fill="rgb(150, 165, 255)"
          d="M15.234,1.397 C14.693,1.623 14.153,1.803 13.521,1.848 C14.153,1.487 14.603,0.901 14.829,0.225 C14.243,0.586 13.611,0.811 12.935,0.946 C12.394,0.360 11.628,-0.000 10.817,-0.000 C9.194,-0.000 7.842,1.307 7.842,2.975 C7.842,3.200 7.887,3.426 7.932,3.651 C5.453,3.516 3.289,2.344 1.802,0.541 C1.532,0.991 1.396,1.487 1.396,2.028 C1.396,3.065 1.937,3.966 2.703,4.507 C2.208,4.507 1.756,4.372 1.351,4.147 L1.351,4.192 C1.351,5.634 2.388,6.806 3.740,7.077 C3.470,7.122 3.244,7.167 2.974,7.167 C2.794,7.167 2.613,7.167 2.433,7.122 C2.794,8.294 3.920,9.150 5.183,9.195 C4.191,10.007 2.884,10.457 1.486,10.457 C1.261,10.457 0.990,10.457 0.765,10.412 C2.117,11.224 3.695,11.719 5.363,11.719 C10.817,11.719 13.792,7.212 13.792,3.290 C13.792,3.155 13.792,3.020 13.792,2.930 C14.333,2.479 14.829,1.983 15.234,1.397 Z"/>
</svg></a></li>
        </ul>
        <div class="footer__copy">
          <p>© 2019 Tagnet. All Right Reserved</p>
        </div>
      </footer>
    </div>
     <div class="class_name" :style="{'--conditional-landing': '' + isLanding + ''}"> </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue, Watch } from 'vue-property-decorator';

@Component({
  components: {}
})
export default class Landing extends Vue {
  isLanding:boolean = true
}
</script>

