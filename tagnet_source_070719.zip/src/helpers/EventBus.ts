import Vue from 'vue'
export const globalEventBus = new Vue()